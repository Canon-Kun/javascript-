@[JS笔记始末]
# js大法

##基础部分

一。  创建变量的六种方式
基于Es语法规范，在Js中创建变量有以下方式
	- Var  （ES3）
	- Function （es3） 创建函数（函数名也是变量，只不过）
	- let（6）
	- const（6）创建的是常量
	- import（es6）基于es6的模块
	- class（6）基于6创建类~
	
```javascript
	/*
	var [变量名] = 值 
	let [变量名] = 值
	const  [变量名] = 值
	function  [函数名]（）{}
*/
var n = 13;
n = 15 ;
alert(n+10);// = >弹出来25，此时的N代表15

const m = 100；
m = 200 ; // = >uncaught typeerror: Assignment to constant variable . 不能给一个常量重新的赋值，不能被修改。
```
创建变量时候的规范（最好按着规范来）
- 严格区分大小写
- 遵循驼峰命名法： 按照数字字母下划线或者$来命名（石子不能作为开头），命名的时候基于英文单词凭借成一个完整名字（第一个单词名字大写，其余每个单词小写）
- 不能使用关键字和保留字：
```
var n = 2 ; 
var N = 2 ;  //=>两个n不是一个变量

var studentInfo / student_info / 
—studentInfo （下划线在前面的一般都是公共变量）
$studentInfo(一般储存的是JQ元素)...
语义化强一些的
	add/create/insert/del/update/remove/info/detail/log/...
```

**使用var操作符定义的变量将成为定义该变量的作用域中的局部变量**

----
数据值是一门编程语言进行生产的材料 ， JS中包含的值 有以下几种类型
- 基本数据类型
	+ 数字 number
	+ 字符串 string
	+ 布尔 boolean
	+ null
	+ undefined
- 引用数据类型·
    + 函数 function
    + 对象 object
	    + 普通对象
	    + 数组对象
	    + 正则对象
	    + 日期对象
	    + ...
- es6中增加的一个：Symbol ， 唯一的值
```
[基本数据类型]
var n = 13 ; //=> 0 ,-12 13.2 数字类型有一个特殊的值 NaN(not a number 代表不是一个有效的数字，但是是属于number类型的)

var s = " "//=>    所有单引号双引号抱起来的都是字符串，里面的内容是当前字符串的字符内容，一个字符串是由多个或者莫得字符组成

var b = true ; //boolean类型只有两个 true lalse

[引用数据类型]
var o = {name:"wjk",age : 9} ; //=>普通对象：里面包含多组属性名和属性值（包含多组键值对）{}空对象

var ary =  [1,2,3,4] ; //=>中括号包含起来，包含多个内容，这种是数组对象 []就是空数组;

var reg = /-?(\d|([1-9]\d+))(\.\d+)?/g; //=> 由元字符组成的一个完整的正则。

function fn(){}

[Symbol]   创建出来的是唯一的值 
 var a = Symbol（'wjk'）;
 var b = Symbol('wjk') ; 
 a==b //=>false； a,b是不一样哒；
```

扩展： JS代码如何被运行以及运行后如何输出结果
【怎么被运行】
- 把代码运行在浏览器中（浏览器内核来渲染解析）
- 基于NODE来运行（NODE也是一个基于V8引擎渲染和解析JS的工具） NODE不是一门语言
【如何输出结果】
- alert ：在浏览器中通过弹出框输出
```javascript
var number = 12 ;
alert(num) ;  //=>window.alert

var str = 'wjk';
alert(str);

alert(1+1);//=>'2'  基于alert输出得结果都会转化成字符串:把值通过toString这个方法转换成字符串，然后再输出！

alert（true）;//=>'true'
alert（[1,2]）;//=>'1,2'
alert({name: xxxx}) ; //=>'[object,object]'
```
 - confirm :和alert的用法一致，只不过提示的框中有确定和取消两个按钮  ，所以他是确认提示框；
 ```
 var flag = confirm('确定要退出吗？')；
 if（flag）{
 //=> flag : true 用户点击的是确定按钮
 }
 else
 {
 用户点击的是取消按钮
 }
 ```
 - consol.log: 在浏览器控制台上输出日志（F12）
	 + elements:当前页面中的元素和样式在这里都可以看到，还可以调节样式，修改结构等
	 + console:控制台 ，可以在JS代码中通过。log输出到这儿，也可以直接在这里干代码
	 + sources：当前网站源文件
 ```javascript
 var num = 12 ;
 /*快捷键 ： num.log TAB*/
 =>   console.log(num);
 ```
 - comsole.dir : 比log输出的更加详细一点（尤其是输出对象数据值的时候）
 - console.table : 把一个JSON数据按照表格的方式输出
 -  。。。（自己回去扩展更多）
 -  ---
 ###数据类型的详细剖析
 1. number数字类型 
 
	 NaN: not a  number  但是它是数字类型
	 isNaN:检测当前值是否是有效数字，返回true代表不是有效数字，反之则是。
	 ```javascript
	 //=>语法：isNaN([VALUE])
	 var num  =  12；
	 isNaN(num)；//=>检测变量储存的值是否为有效数字 false
	 isNaN('13');=>false
	 isNaN('wjk');=>true
	 isNaN(true)=>false
	 isNaN(false)=>false
	 isNaN(null)=>false
	 isNaN(undefined) =>true
	 isNaN({age: 9 }) =>true
	 isNaN([12,23])  =>true
	 isNaN([12]) =>false
	 isNaN([])=>false	   函数正则都是true
	 ``` 

	
	重要：isNaN检测的机制


	 1. 首先验证当前要检测的值是否为数字类型的，如果不是，浏览器会默认把值转换成数字类型
	 
		>把非数字的值转换成数字：
		- 其他基本类型转换成数字：  直接使用Number这个方法进行转换
		[字符串转换成数字]
		Number('14')-> 14
		Number('13px')->NaN  如果当前字符串中出现任意一个非有效数字字符，结果就是NaN。
		[布尔类型·转成数字]
		Number(true)->1;
		false->0;
		[其他类型转换成数字]
		Number(null) - > 0 ;
		Number(undefined) - >NaN
	- 把引用数据类型转换成数字：  先把引用值调取toString转换成字符串，然后再把字符串调取Number转换成数字
	[对象]
	({}).toString() - >'[object , object]' ->  NaN
	[数组]
	[122,23].tostring() ->'12,23' - >NaN(因为出现了逗号)
	[正则]    直接NaN了
	```
	Number('')->0;//这个很重要
	[].tostring()->''
	=>isNaN([]): false;
	```

2.档期那检验的值已经是数字类型，则按照规则返回相应的值。
	
>parseInt/ parseFloat 
>
>等同于Number ，也是为了把其他类型的值转化成数字类型
>和Number的区别在于字符串转换分析上
>
>Number : 出现任何非有效数字字符，结果就是NaN
>
>parseInt：   把一个字符串中的整数部分解析出来;
>parseFloat:   是把一个字符串的小数部分解析出来
>两者都是从字符串最左边查找有效数字字符，并转换成数字，但如果遇到一个非有效数字字符，查找结束。
>譬如：parseInt（width：13px）//=>NaN




·
>NaN的比较
>
```
NaN == NaN   //FALSE   它和谁都不相等
```

---

---
###布尔类型详解
>只有两个值  true/false

.

>如何把其他数据类型转换成boolean呢？

- Boolean
- !
- !!
```javascript
Boolean(1) => true
Boolean(0/NaN/undefined) =>false

!'wjk' =>先把其他类型转换为boolean ，然后取反；
!!null =>去两次反，同上面的功能查案不多

```
规律：**`` 在JS中只有“0/NULL/空字符/undefined”这五个值布尔值为假，其余都可以转换成true``**

###null&&undefined
>都是代表没有，嗯啊
>- null ：空对象指针
>- undefined：未定义

null一般都是意料之中没有的，后面的程序可以再次给他赋值。

undefined代表地是不是人为控制地，大部分是浏览器自主为空（后面可以赋值也可以不赋值）



------

------
###object对象数据类型
>普通对象
>- 由大括号包裹起来
>- 有多组属性名属性值（键值对）组成
```javascript
var obj = {
	name =  "wjk" , 
	age = 9 
};
// =>对象的操作 ， 对键值对的增删改查
[获取]
语法： 对象.属性  / 对象[属性]
obj.name    
或者obj['name']//一般来说对象的属性名是字符串格式的
[增加和改动]
JS对象中属性名不可以重复的，是唯一的。
obj.name = 'lalala' ; //=>这个属于修改
obj.sex = 'man' ; //这个就属于增加了·
[删除]
彻底删除   
delete obj.age ; //对象中就不存在这个属性了
假删除:并未删除这个属性，只是变成空了
obj.sex = null;

如果在获取属性值的时候，当前对象有这个属性名则可以正常获取，undefined就不可以啦。
```



思考题
```javascript
var obj = {
name : 'wjk' , 
age ：9
};
var name = 'lalala';

obj.name => 'wjk'
obj['name'] => 同上
obj[name] =>

----
'name'  和   name 的区别
'name' 是一个字符串值
name   是一个变量不是一个值 ，代表的是本身存储的这个值

```

一个对象中的属性名不单单是字符串格式，还有数字格式的

```
var obj = {
	0:100
};
obj[0]/obj['0']  可以
但是木的obj.0 ; 
----
当我们存贮的属性名也不是数字的时候，全部用toString转换字符串，然后再进行存储

obj[{}] = 300 ; 先把{}.toString()后的结果为对象的属性名字存储进来  obj['[object,object]'] = 300

```

----

----

###浅分析JS的运行机制
1.当浏览器渲染和解析JS时，会提供一个供JS代码运行的环境，称之为全局作用域（global/window  scope）
2. 代码自上而下运行（之前还有一个变量提升阶段）
=>基本数据类型的值会存储在当前作用域下。
var a = 12 的三部操作
  - 首先开辟一个空间储存12
  - 在·当前作用域中声明一个变量 a （var a）
  - 让声明的变量和存储的变量相关联
  - 上述三种操作统称之为定义
   >**基本数据类型 **是按照值来操作的，把原有的值复制一份放到新的空间或者位置上，和原来的值没有关系
   譬如
   ```javascript
   var a = 2 ;
   b = a;
   b = 13
   ```

> 引用数据类型不是按值来操作，它操作的是空间的引用地址：把原来空间的地址赋值给新的变量，但是原来的空间没有被克隆，还是那一个空间，这样就会有多个变量关联的相关的空间，所以相互就会产生影响了



**栈内存** : 本身就是一个供JS代码执行的环境 所有的基本类型都会直接在栈内存开辟一个位置进行储存。 
**堆内存**:用来储存引用类型中的信息值的  对象储存的是键值对   函数储存的是代码字符串。

**例题 1**
![Alt text](./1564467018041.png)


---------

---------
###JS中的判断操作语句
1. if-else/else if/else  语句
```javascript
if('3px'+3)
{
//=>在JS中，+-*%都是数学运算，除+以外，其余运算符在运算时，如果遇到了非数字类型的，首先会转换成数字（NUMBER）再计算  +用于字符串相加
}

```
typeof ：在JS中用于检测数据类型的方式之一
还有下面三种
>- instanceof
>- constructor
>- Object.prototype.toString.call()


语法：typeof[value] =>检测的是value的数据类型
返回值：结果是一个字符串，里面包含着对应的数据类型，例如~~

typeof null = "object"     //null代表空对象指针（没有指向任何的内存空间）

typeof检测数组/正则/对象都是  object

2.三元运算符
>语法：条件？成立做什么：不成立做什么
特殊情况：
```javascript
//=>如果三元运算符中的某一部分不需要处理，我们用null/undefined/void 0 ....占位即可

var num = 12；
num>10?num++:null;
//=>如果需要干多个事情，用小括号括起来，每条操作语句用逗号分离
num = 10 ;
num >= 10 ?(xxx,xxx):null;

```


3.switch  case
>js中的一种判断方式

应用于一个变量在不同值情况下的不同操作，每一种case结束后都要加break（结束整个判断）

n++和n+1并不完全一样，n++用于字符内的加法
如： n = ‘10’ ；n++ =>n = '11''


switch  case 中的每一种情况都是基于“===”绝对相等来完成的
```javascript
'10'==10 //=>true;
如果当前等号两边的类型不一样，首先会转换成一样的数据类型，然后再惊进行比较。

项目中应用绝对比较！！
```

###for循环
>作用;按照一定规律去循环做某些事情。

例如：
输出数组中的每一项
/*==itar【TAB】 自动补全代码*/

**基本语法组成**:
1.初定义初始值
2.设置循环条件
3.条件成立会执行循环体的内容
4.执行步长累加的操作

**常出现的两个关键字**
1.continue
2.break


**获取页面中的DOM元素**	``document.getElementById
``
> 在整个文档中，通过元素的ID属性值，获取到这个元素对象
> 
> getElementById是获取元素的方法，而document限定了获取元素的范围，我们把这个范围称之为:"上下文[context]"

```javascript
var oBox = document.getElementById('box');


1.通过getElementById获取的元素是一个对象数据类型的值（里面包含很多内置的属性）

typeof  oBox  =>'object'

2. 分析包含的属性
	 className :储存的是一个字符串，代表当前元素的样式
	 
	 id : 储存当前元素的ID值，也是字符串。

	innerHTML：储存当前元素的所有的内容，包括html标签
	 
	innerText ： 存贮当前元素中的所有文本内容·，没有元素标签

	onclick :元素的一个事件属性，基于这个属性，可以给当前元素绑定事件
	onmouseover： 鼠标划过事件
	
	onmouseout：鼠标移出事件

	style：储存的是当前元素的行内样式值（获取和操作都只能是写在标签上的行内样式值）

-------------------------------
//想要修改BOX的样式类
1.通过style属性值来修改**行内样式**
2. 基于className属性修改样式类，从而改变样式


----------


```
样例如下;
![Alt text](./1564571407985.png)
![Alt text](./1564571501634.png)

``[context].getElementsByTagName
``
>在指定的上下文中，通过元素的标签名获取一组元素集合
>上下文是我们自己来定的！！！嘤嘤嘤

1.获取的结果是一个元素集合（HTMLCollection），首先他也是对象数据类型的，结构和数组十分相似（数字作为索引，length表示长度），但我们把他叫做类数组

譬如
```javascript
var boxlist = oBox.getElementsByTagName('li');

boxlist[0] ;//获取当前集合中的第一个li
boxlist.length;//获取集合中li的数量
```


-------

-------
###函数
>在JS中，函数就是一个方法（一个功能体），基于函数一般是为了实现某个功能，开发时更加高效！
譬如
```javascript
function fn(){
var total = 10;
total+=10;
}
```
ES3标准中：
//=>创建函数
function 函数名([参数])
{

}
//=>函数执行
函数名（）;

ES6标准中创建箭头函数:
let 函数名（变量名） = （[参数]）=>{
	函数体
}
函数名（）;

函数作为引用数据的一种，他也是按照引用地址来操作的。
**[创建函数]**

1. 函数也是引用类型，首先会开辟一个新的堆内存，把函数整体的代码当作字符串储存到内存中（对象向内存中储存的是键值对）
2. 把开辟的堆内存地址赋值给函数名(变量名)

**注意**
此时我们输出fn  代表函数本身
fn()这是把函数执行
所以这两种操作本质上不经相同！

**[函数执行]**
1.函数执行，首先会形成一个私有作用域（一个供代码运行的环境，也就i是一个栈内存。）
2.然后从堆内存中复制代码变成真正的JS代码，在新开辟的作用域中自上而下进行

**函数中的参数**

> 参数是函数的入口，当我们在函数中封装一个功能的时候，发现有不确定的原材料，需要执行函数的时候用户传递过来才可以，此时我们就基于参数的机制，提供出入口即可！

 例如



```javascript
 function sun(n,m)
 {
	 var total = 0 ; 
	 total = n+m;
	 console.log(total);
 }
 //=>此处函数执行的传递的值是实参；实参是具体的数据值
 sum(10,20);
 sum(10);//=>n=10;m=undefined;
 sum();//两者都是undefined
 sum(10,20,30);//=>30没有形参变量接受 
```

所实验的源码;
```
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>帅哥王靖锟</title>
		<style type="text/css">
			*{
				padding:0;
				margin: 0;
			}
			ul li{
				list-style: none;
			}

			.table{
				width: 62.5rem;
				margin:   auto;
				overflow: hidden;
              }
			.table li{
				display: inline-block;
				width: 50px;
				text-align: center;
				cursor: pointer;
				line-height: 2.0625rem;
				border: 1px  solid antiquewhite ;
				/* margin:  0 auto; */
			}
			.table div{
				position: relative;
				top: 0.0625rem;
				display: none;   
/*visbility :这个占空间的*/
				text-align: center;
				width: 62.5rem;
				height: 12.5rem;
				border: 1px solid  antiquewhite;
			}
			.table li.active{
				border-bottom: white;
			}
			.table div.active{
				display: block;
			}
		</style>
	</head>
	<body>
	<div class="table" id="tabBox">
			<ul>
				<li class="active">新闻</li>
				<li>电影</li>
				<li>音乐</li>
			</ul>
			<div class="active">王靖锟依然是单身</div>
			<div>一路向西</div>
			<div>我是你爹</div>
		</div>
	</body>
	<script src="1.js"></script>
</html>

```

```javascript
var tabbox = document.getElementById('tabBox')
var tablist = tabbox.getElementsByTagName('li')
var tabdiv = tabbox.getElementsByTagName('div')

function changtag(n)
{
	for(var i = 0 ; i < tablist.length ; i++)
	{
		tablist[i].className = '';
		tabdiv[i].className = '';
	}
	tabdiv[n].className = 'active';
	tabbox[n].className = 'active';
}


for(var i = 0 ; i<tablist.length ; i++)
{
	tablist[i].tabIndex = i;
	tablist[i].onclick = function()
	{
		changtag(this.tabIndex)
	}
}
//=>添加自写属性，哈哈哈
//=>选项卡测试成功！
```


###JS中数据类型的转换汇总
JS的数据类型
【基本数据类型】
数字  number
字符串  string
布尔 boolean
null
undefined
【引用·数据类型】
对象  object
			-  普通对象
			-  数组对象
			-  正则对象
			-  日期对象
			-  数学函数
			-  。。。
函数 function
true == 2 /false
null == 0 /false
undefined / false
switch语句在比较值时是全等符号，不存在数值转换。
**1.把其他类型转换成number类型**
- isNaN检测的时候，当检测不是数字类型的的时候，浏览器会自己调用Number方法把它先转换成数字，然后再检测是否为有效数字
- 基于parseInt / parseFloat/ Number 去手动转换为数字类型
- 数学运算：+ - * / % ，但是“+”不仅仅是数学运算，但还可能是字符串拼接
```javascript
'3' -1=>2
	Number('3')->3;
	3-1 = 2
'3px' -1=NaN
'3px'+1 = '3px1'  字符串的拼接
```
- 在基于“==”比较的时候，有时候会把其他值转换成数字类型


> 转换规律：
> //=>转换方法  Number(浏览器自行转换就按这个来了)
> 【把字符串转换成数字】
> '\n' - > 0 
> '\t' - >0
> 只要遇到一个非有效数字，结果就是NaN
> 【布尔】   相当简单
> 【把没有转换成数字】
> null->0 ; undefined-> NaN
> 【把引用数据转换成数字】
> 首先都先转换成toString 然后转换成数字（Number）


. **把其他方式转换成字符串**
- 基于alert/confirm/prompt/document.write等方法输出的时候，会把输出的值转换成字符串，然后再输出
- 基于“+”字符串拼接的时候
- 把引用类型转化为数字的时候的第一步
- 给对象设置属性名，如果不是字符串，首先转换成字符串，然后再当作属性储存在对象中

>转化规律
>【除了对象，都是你理解的结果】
>【对象·】
>{name：XXX}/{}
>都是['object' ,'object']



**把其他值转换成boolean**
- 基于！，！！，Boolean等方法转化
-  基于判断条件来转换
>转化规律
>0/NaN/""/NULL/undefined  五个值转换成false


**特殊情况：数字运算和字符串拼接**

[12]+10=>1210;
({}) + 10 =>"[object object] 10"
[]+10 =>'10'

{}+10 => 10  //这不是数学运算，也不是字符串拼接
他是两部分代码。{}是一个作用域（代码块）

**特殊情况：“==”在进行比较的时候先转换成相同的类型，再进行比较！**

对象==对象   不一定相等  ，对象操作的是引用地址，地址不一样，则不一样。

对象==数字   ：把对象转换成数字

对象==布尔  把对象转换成数字，布尔一样

对象==字符串  ：  两者都是转换成数字！

字符串==数字 ：字符串转换数字


字符串==布尔：  都是数字

布尔==数字  ；转换成数字

null==undefined  true
null===undefined   false
null&&undefined和其他值不一样

NaN和谁都不一样！

例子如下！
![Alt text](./1564902818081.png)



###关于js数组常用方法的剖析
数组也是对象数据类型的，也是由键值对组成的
```javascript
var ary = [1,2,3]
/*
结构：
0:1
1:2
2:3
length:3
//ary[0]获取第一项
ary[ary.length - 1] 获取最后一项
*/
```
数组中的每一项的值都可以是任何数据类型的
```javascript
//=>多维数组
var ary = [
{name:'xxx',age:20},{name:'xxx' , age:18}
];
```

**数组当中的常用方法:**
>四个维度记忆
>- 方法的作用
>- 方法的参数
>- 方法的返回值
>- 原有数组是否改变

**1.push**

作用：向数组末追加新的内容

参数：追加的内容（可以是一个·，也可以是多个）

返回值：**新增数组后的长度**

**2.pop**
作用： 删除数组最后一项

参数：没有

返回：**被删除的最后一项**

原有数组就改变了！
![Alt text](./1564904236437.png)

**3.shift**
作用： 删除数组中的第一项
参数：木有
返回 ： **被删除的那一项内容**
原有数组改变

 ![Alt text](./1564904399957.png)
 
**4.unshift**
作用： 向数组开始位置追加新的内容
参数：要新增的内容
返回：  **新增后数组的长度**
原有数组改变

**5.splice**
基于SPLICE可以对数组进行很多操作：删除指定位置的内容，向数组指定位置增加内容，还可以修改指定位置的
信息。

- **删除**   
		-	语法：ary.splice(n,m)
		-	从索引n开始，删除m个内容，把**删除的部分以一个新的数组返回**，原有数组返回
![Alt text](./1564915078900.png)

- **新增**
	- 语法：ary.splice( n   ,  0  ,  x  ,  ......)
	- 从索引n开始删除0项，把x或者更多项目添加放到数组中索引n的前面去
![Alt text](./1564915370857.png)
返回空数组的原因是返回的是删除的元素（因为莫有，所以是空数组）

- **修改**
	- 语法：ary.splice(n,m,x,....)
	- 从索引n开始删除m个元素，并用x以及更多元素替代，返回的就是删除的元素！
	
![Alt text](./1564915731197.png)

>需求扩展
>1. 删除数组最后一项有几种办法？
>2. 向数组末尾添加新的内容，你有几种办法？

答案：
```javascript
//  删除最后一项的方法：

ary.pop();
ary.splice(ary.length-1);
ary.length -- ;
//注意不要用delete来删除，会有一个empty占空~~长度并未改变~~~~

//向数组末尾添加新内容
ary.push(100);
ary.splice(ary.length , 0 , 100);
ary[ary.length] = 100;

```
![Alt text](./1564916365787.png)

---

**6.slice**
- 语法  slice（n,m）
- 查询由索引n到m的元素形成一个新数组   
 //             注意是[n,m),左闭右开~
- 如果没有第二个参数，就一直查找到末尾
- 实现数组克隆可以两个参数都不加，克隆出的数组和原数组数值一样，但是不是相同的内存空间，两个数组是不相等独立的
- 支持负数索引，可以理解为   数组总长度+这个负数！

![Alt text](./1564917538990.png)

**7.concat**
- 实现多个数组的拼接
- 参数：数组或者值
- 返回： 拼接后的新数组
- **原有数组是不变的！**
![Alt text](./1564917910815.png)

**8.toString**
作用:  把数组转化为字符串
参数：无
返回：数组中的每一项用逗号分隔的字符串，原有数组不变~~~

**9.join**
作用： 和tostring类似，也是把数组准换成字符串，但是我们可以设置字符串之后，每一项之间的连接符~~
参数：指定的连接符
返回： 字符串
原有数组不变！
![Alt text](./1564919709756.png)


**10.reverse**
作用：把数组倒过来排列
参数：无
返回：排列完之后的数组
原有数组改变

**11.sort**
作用：给数组排序
参数：无/函数
返回：  排序后的新数组
原有数组就改变了！
//sort再不传递参数的情况下只能处理10以内的排序
//真实项目中需要传递参数~~~
例如
```javascript
var ary = [1,16,24,8,70]

ary.sort(function(a,b)
{
return a-b;//这是升序
return b-a;//这是降序
}
)

```
**12.indexOf /lastIndexOf**
这两个方法不兼容IE低版本浏览器
作用：  **检测当前值在数组中第一次或者最后一次的索引**
参数：要检测的值
![Alt text](./1564973121608.png)
如果这个值没有出现，返回-1；
（用于验证数组中有木有这个值~~~）


除了上述方法：  数组中还包括很多常用方法
（Array.prototype）
- every
- filter
- find
- forEach
- includes
- keys
- map
- reeduce/reduceRight
- some
- ....

第一阶段不深入了解研究这些方法，搞懂这些需要了解oop/作用域/回调函数等，第二阶段再去研究~~
###数组去重

```javascript
//数组去重
var ary =  [1,2,3,2,3,4,3,4,5];
/*双for循环*/
for(var i = 0 ; i < ary.length-1 ; i++)
{
	var item = ary[i];
	for(var k = i+1 ; k<ary.length ; k++)
	{
		if( item==ary[k] )
			{
			ary.splice(k,1);
			//k-1;
			}
	}

}
```
上述写法会导致数组塌陷问题，有bug鸭~~,

注释里面的内容是很重要滴~~~
```javascript
var ary = [1,2,3,2,2,3,4,3,4,5];
/*
基于对象的属性名不能重复，我们实现高新能的数组去重
1.创建一个空对象
2.依次遍历数组中的每一项，把每一项储存的值，当作对象的属性名和属性值储存起来
*/
var obj = {};
for(var i = 0 ; i < ary.length ; i++)
{
	var item = ary[i] ; 
	//首先判断这个在对象中是否重复了，如果重复就删掉
	if(typeof obj[item] !== 'undefined')
	{
		ary.splice(i,1);
		i--;//防止数组坍塌，因为已经少了一个啦
		continue;
	}
	obj[item] = item;
}

```

第三种方法
```javascript
var obj = {};
for(var i = 0 ; i < ary.length ; i++)
{
	var item = ary[i] ; 
	//首先判断这个在对象中是否重复了，如果重复就删掉
	if(typeof obj[item] !== 'undefined')
	{
		ary[i] == ary[ary.length - 1];
		ary.length--;
		i--;
		continue;

	}
	obj[item] = item;

```
###js中关于字符串的一些细节知识
```javascript
var str = 'zhufengpeixun';
str.length - > 字符长度；
str[0] ->'z';
str[str.length-1] ->'n';
str[100000]->undefined;
```
**字符串中常用方法：**

字符串的每一步操作都是值操作，不像数组一样是基于空间地址操作

**1.charAt/charCodeAt**

作用：charAt根据索引获得指定位置的字符，charCodeAt不仅仅获取字符，它获取的是字符对应的Unicode编码值（ASCII）

参数：索引

返回： 字符或者对应的编码

str[1000] =  undefined;
str.charAt(1000) = '' '';


**2.indexOf/lastIndexOf**

基于这两种方法，可以获取字符在字符串中第一次或者最后一次出现索引的位置。可以基于这两种方法，验证是否包含某个字符~~

**3. slice**

作用：  str.slice(n,m)从索引n开始一直到m（【n,m)  ）
返回查找的值，与数组相似鸭。

**4.substring**

和slice语法一模一样，区别就是substring不支持负数索引~~

**5.substr**

也是字符串的截取方法，用法是从索引N开始，截取m个字符，也支持第一个参数是负数。用法与数组那个相同。
![Alt text](./1565000547467.png)


**6.toUpperCase/toLowerCase**

实现字母的大小写转换，前者都变成大写，后者都变成小写

**7.split**
和数组中的join相对应，数组中的join是把数组们一项按照指定的连接符变为字符串，而split是把字符串按照指定的分隔符，拆分成数组中的每一项。

![Alt text](./1565001110528.png)

**8.replace**

作用：替换字符串中的原有字符
参数：原有字符，要替换的新字符
返回：替换后的字符串
```javascript

var str = 'zhufeng2017zhufeng';
str = str.replace('zhufeng' , 珠峰);
//在不使用正则的情况下，每执行一次只能替换一个

```

还有以下几种方法，回去之后可以拓展：（String.prototype）
- includes
- localeCompare
- search
- trim
- 。。。。

###真实项目中的需求
``1.时间字符串格式化``
> 有一个时间字符串“2019-8-5 18:49:20”，我们想基于这个字符串获取到“08月05日  18时49分”
```javascript

var str = '2019-8-5 18:40:04';
var ary = str.split(' ');
var aryLeft = ary[0].split('-'),
	aryRight = ary[1].split(':');

function addzero(val){
	return val<10 ? '0'+val:null;
}
var month = addzero(aryLeft[1]),
	day = addzero(aryLeft[2]);
	
var TiMe = month + '月' + day +'日' +aryRight[0]+'时'+aryRight[1]+'分'+aryRight[2]+'秒';
	
	console.log(TiMe);
	
```

``2.url地址问好传参解析``

> 有一个url地址："http://www.baidu.com/stu/?lx=1&name=x&sex=man#teacher"问号后面的内容是我们要解析的参数信息 
>  #  后面的内容称之为哈希值，这个值可能有可能没有，我们需要处理，有的话我们需要过滤掉
> {
> lx：1；
> name：x；
> sex ：man；
> }
示例代码如下：

```javascript
var str = 'http://www.baidu.com/stu/?lx=1&name=x&sex=man#teacher';
var indexAsk = str.indexOf('?');
var indexWell = str.indexOf('#');
if(indexWell>-1)//判断是否有井号
{
	var shapestr = str.substring(indexAsk +1 ,indexWell);
}else
{
	var shapestr = str.substring(indexAsk);
}
var obj = {};
var ary = shapestr.split('&');
for (var i = 0; i < ary.length; i++) {
	var item = ary[i];
	var temp = item.split('=');
	obj[temp[0]] = temp[1];
}
console.log(obj);

```
###JS中的数学函数Math
Math称之为数学函数，但是它属于对象类型的
```javascript

typeof Math = 'object'

```
Math中提供的常用方法：

**1.abs**    取绝对值
**2.cell/floor** 向上或者向下取整
**3.round** 四舍五入
**4.sqrt** 开平方
**5.pow**n的m次方
**6.max/min**获得最大值/最小值
**7.PI**获取圆周率
**8.random** 获取0-1的随机小数
**9.Math.round(Math.random()*(m-n)+n)**  获取n-m之间的随机整数

---
>函数执行时，都会形成一个全新的私有作用域（私有的栈内存），目的是：
- 把原有堆内存中储存的字符串变为js表达式之后再执行
- 保护里面的私有变量不受外界环境的干扰，我们把函数执行的这种保护机制称之为**闭包**
- return 返回的永远是一个值
- 如果当前函数莫得返回值，函数执行后在外面拿到的结果就是undefined
- n===undefined这种判断方式可以，但是我们更喜欢typeof n == 'undefined';
- 开发者更喜欢用null作为初始值。
- ---

###arguments: 
函数内置的实参集合（内置：函数天生就有的机制，不管是否有形参或是传递实参，arguments都有，始终存在）
arg是一个类数组（不能使用数组方法）
即使设置形参变量，形参不管是什么值，arg储存的是所有的传递进来的实参，所以被称之为实参集合
```javascript
function sum(n,m)
{
	console.log(argument.callee === sum);


/*
{
	0: 10;
	1: 20;
	length: 2;
	callee: 储存的是当前函数本身  
	//arguments.callee === sum : true;
}
*/
}
```
基于arguments实现和函数
```javascript
function sum()
{
	var total = null;//开发人员建议用null，不用0；
	for (var i = 0; i < arguments.length ; i++) {
		
		var item = Number(arguments[i]) ;//都转换成数字类型
		isNaN(item) ? null : total += item ;
	}
	return total;
	
}
console.log(sum(1,2,3,4,5,6,7,8,9,10));

```
实名函数：有函数名的
匿名函数： 没有函数名称的
 - 函数表达式： 把函数当作值赋值给变量或者元素的事件
 - 自执行函数： 创建和执行一起完成的
譬如
```javascript
//这tmd就是函数表达式
var fn = function(){

};
//这tmd叫自执行函数
(function(){}) ();
~function(){}();
+function(){}();
!....
```

###综合练习---获取四位验证码
```javascript
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<style type="text/css">
			*{
				padding: 0;
				margin: 0;
			}
			#code{
				width: 100px;
				height: 50px;
				line-height: 50px;
				letter-spacing: 15px;
				border: 1px solid #000000;
				font-size: 1.125rem;
				font-weight: bold;
				overflow: hidden;
			}
		</style>
	</head>
	<body>
		<div id="code">A12E</div>
		<a id="change" href="javascript:;">看不清楚点这里~</a>
		<script type="text/javascript" src="js/四位验证码.js">
			
		</script>
	</body>
</html>

```

js部分代码
```
var code = document.getElementById('code');
var change = document.getElementById('change');

var codearea = 'qwertyuiopasdfghjklzxcvbnm1234567890QWERTYUIOPASDFGHJKLZXCVBNM';
function addcode(){
	var newcode = '';
	for (var i = 0; i < 4; i++) {
	
	var index = Math.round(Math.random()*(codearea.length-1))//每一位的索引随机生成；
	
	newcode += codearea.charAt(index);
	
}
return newcode;
}

	code.innerHTML = addcode() ;
	change.onclick = function()
	{
	code.innerHTML = addcode() ;
	};

```
###DOM及其常用方法
>dom tree
>当浏览器加载html页面时，首先就是DOM结构的计算，计算出来的dom结构就是dom树（层级关系）

**在JS中获取DOM元素的方法**

DOM树描述了标签与标签之间的关系，我们只要知道任何一个标签，都可以依据DOM中的属性和方法，获取到页面中任意一个标签或者节点

`` getElementById``
> 通过元素的ID来获取指定的元素对象，使用的时候都是document.getElementById（‘’）此处的document是限定了获取元素的范围，将其称之为上下文

1.getElementById的上下文只能是document，因为严格意义上一个页面上的ID是不能重复的，浏览器规定在整个文档中就可以获取这个唯一的ID。

2.如果页面中的ID重复了，我们基于这个方法只能获取第一个元素，后面就得不到了。

3.在ie6-7，会把表单元素input 的name属性值当作ID来使用。使用表单元素不要让name和id的值有冲突

`` getElementsByTagName``
>在指定的上下文中，根据标签名获取一组元素集合。获取的是一个类数组，但不能使用数组方法。

1.他会获取上下文中子子孙孙的标签元素，获取的不仅仅是儿子级的。

2.基于这个方法获得的永远都是**一个集合**，如果想操作集合中具体的某一项，需要基于索引来获取。


`` getElementsByClassName``
>在指定上下文中，基于元素的样式类名获取到一组元素**集合**

1.真是项目中，我们经常用样式类来给元素设置样式，获取元素，但在ie6-8中就不兼容了

`` getElementsByName``
>它的上下文也只能是document，基于元素的name属性来获取一组节点集合（也是一个类数组）

1.在IE中，只对表单元素的name属性起作用，正常只对表单元素设置name值

`` querySelector``

> 在指定的上下文中，基于选择器获取到指定的元素对象（获取的是一个元素，哪怕选择器匹配了多个，我们只获取一个）


`` querySelectorAll``

>再上一个的基础上，我们获取的是一个元素集合。上面两个是不兼容IE6-8浏览器的（这两个方法性能消耗较大。）

`` document.head``
获取head元素对象
`` document.body``
获取body元素对象
`` document.documentElement``
获取html元素对象


```javascript
document.documentElement.clientWidth || document.body.clientWidth

document.documentElement.clientHeight ||
document.body.clientHeight
```

小练习： 获取所有ID元素元素（兼容所有浏览器）
```javascript
/*
1.首先获取当前文档的多有html标签
2.依次遍历这些元素标签对象，谁的ID是haha，我们存储起来就好。
*/
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<div id="4"></div>
		<div id="4"></div>
		<div></div>
		<div id="4"></div>
		<script src="js/获取ID名相同的所有元素.js"></script>
	</body>
</html>
```
```javascript
js部分
var nodelist = document.getElementsByTagName('*');//获取所有元素
var array = [];定义一个空数组
function queryAllId(id)
{
	for (var i = 0; i < nodelist.length; i++) 
	{
	id===nodelist[i].id?array.push(nodelist[i]):null;
	}
	return array;
}
console.log(queryAllId('4'));

```

###DOM中的节点（node）
>在一个html文档中出现的所有东西都是节点
>
>- 元素节点（html标签）
>- 文本节点（文字内容）
>- 注释节点（注释内容）
>- 文档节点（document）
>- ....



每一种类型的节点都会有一些属性区分自己的特性和特征
- nodeType：节点类型
- nodeName：节点名称
- nodeValue： 节点值


`元素节点`
nodeType： 1；
nodeName： 大写标签名
nodeValue： null；


`文本节点`
nodeType：3
nodeName：‘#text’
nodeValue：文本内容

标准浏览器中，空格和换行都是文本节点

`注释节点`
nodeType：8
nodeName："#common"
nodeValue: 注释内容

`文档节点`

nodeType： 9
nodeName：‘#document’
nodeValue：null

**描述节点之间关系的属性**

``parentNode``
> 获取当前元素唯一的父亲节点

`childrenNodes`
> 获取当前元素的所有子节点
>  - 子节点：只获取儿子级别的
>  -所有：包含元素节点，文本节点

`childen`
> 获取当前元素所有的元素子节点
> ie6-8中会把注释节点也当做元素节点来获取，所以兼容性不好

``previousSibling``
> 获得当前节点的下一个弟弟节点（可能是元素，也可能是文本）

>previousElementSibling：上一个哥哥元素节点（）

``nextSibling``
>获取当前元素下一个弟弟节点
>
>nextElementSibling: 下一个弟弟节点（不兼容）

``firstChild``
>获取当前元素的第一个子节点（可能是元素，可能是文本）
>
>firstElementChild

``lastChild``
>获取当前元素的最后一个子节点
>
>lastElementChild



**获取当前元素所有元素子节点**
>基于children不兼容IE

自己编写代码如下;
```javascript
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<div id="box">
			<div></div>
			<div></div>
			<div></div>
		</div>
		<script src="js/获取当前元素的所有元素子节点.js"></script>
	</body>
</html>

```
```javascript
function children(curEle){
	var nodelist = curEle.childNodes;//获取当前元素下的所有子节点
	var result = [];
	for (var i = 0; i < nodelist.length; i++) {
		nodelist[i].nodeType===1?result.push(nodelist[i]):null;//基于nodeType来判断是否是元素节点，用push方法添加到空数组中；
		
	}
	
		return result;
}
console.log(children(box));
```

练习二 ：获取当前元素的哥哥元素节点
```javascript
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<div>
			<ul>
				<li></li>
				<li></li>
				<li id="bro"></li>
				<!---->
				<!---->
				<li id='cur'></li>
				<li></li>
			</ul>
		</div>
		<script src="获取当前元素的哥哥元素节点.js"></script>
	</body>
</html>


```
```javascript
function bro(cur){
	var brother = cur.previousSibling;
	while(brother && brother.nodeType!==1)
	{
		brother = brother.previousSibling;
	}
	return brother;
}
console.log(bro(cur));
```
可以扩展：next下一个弟弟元素节点，preAll获取所有哥哥元素节点，nextAll获取所有弟弟元素节点，siblings获取所有兄弟元素节点，index获取当前元素索引

###关于DOM的增删改
``creatElement``
>**创建**一个元素标签/元素对象

>语法： document.createElement([标签名])




` appendChild`
>把一个元素对象插入到指定容器的**末尾**
>[container].appendChild([newEle])

` insertBefore`
>把一个元素对象插入到指定容器中某一个元素标签之前
>[container].insertBefore([newEle],[oldEle])

` cloneNode`
>把某一个节点克隆
>[cur].cloneNode():  浅克隆，只克隆标签
>[cur].cloneNode(true): 深克隆，当前标签和里面的内容都一起克隆了。

` removeChild`
>在指定容器中删除某一个元素
>
>[container].removeChild([curEle])

` set/get/removeAttrubute`//这种方式不建议使用
>设置获取和删除当前元素的某一个自定义属性

```javascript
//=>基于Attribute等DOM方法完成自定义属性的设置
obox.setAttribute('mycolor'  , 'red');//这是设置属性
obox.getAttribute('mycolor')//这是获取属性
obox.removeAttribute('mycolor')//这是移出属性

```